package com.shri.assistant;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public class ThemeHelper {
    private static final String PREF = "theme_pref";
    private static final String KEY = "dark_mode";

    public static void applySavedTheme(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        boolean dark = sp.getBoolean(KEY, false);
        AppCompatDelegate.setDefaultNightMode(
                dark ? AppCompatDelegate.MODE_NIGHT_YES
                     : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    public static void toggleTheme(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        boolean dark = !sp.getBoolean(KEY, false);
        sp.edit().putBoolean(KEY, dark).apply();
        applySavedTheme(context);
    }
}
