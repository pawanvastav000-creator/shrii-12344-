package com.shri.assistant;

import android.content.Intent;
import android.service.notification.NotificationListenerService;
import android.view.KeyEvent;

public class MusicControlService extends NotificationListenerService {

    public void playPause() {
        dispatchMediaButton(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
    }

    public void next() {
        dispatchMediaButton(KeyEvent.KEYCODE_MEDIA_NEXT);
    }

    private void dispatchMediaButton(int keyCode) {
        Intent downIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
        downIntent.putExtra(Intent.EXTRA_KEY_EVENT,
                new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
        sendOrderedBroadcast(downIntent, null);

        Intent upIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
        upIntent.putExtra(Intent.EXTRA_KEY_EVENT,
                new KeyEvent(KeyEvent.ACTION_UP, keyCode));
        sendOrderedBroadcast(upIntent, null);
    }
}
