SHRI APP - NEW FEATURES

Added:
1. Dark / Light Theme
2. OCR Activity (Image to Text)
3. Music Control Service

STEPS:
- Copy Java files into your app package.
- Copy XML file into res/layout.
- Merge AndroidManifest_additions.xml into your AndroidManifest.xml.
- Add ML Kit dependency:

implementation 'com.google.mlkit:text-recognition:16.0.1'

Example button:
ThemeHelper.toggleTheme(this);

Open OCR screen:
startActivity(new Intent(this, OcrActivity.class));
